import Footer from '@/components/Footer'
import Header from '@/components/layouts/Header'


const page = () => {
  return (
    <div>
      <Header />

      


      <Footer />
    </div>
  )
}

export default page
