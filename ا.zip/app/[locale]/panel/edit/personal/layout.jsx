export const metadata = {
  title: "ویرایش اطلاعات شخصی | پالم رنت",
  description: "ویرایش اطلاعات شخصی",
  icons: {
    icon: '/favicon.png',
  },
};

export default function PanelLayout({ children }) {
  return (
    <>
        { children }
    </>
  );
}
