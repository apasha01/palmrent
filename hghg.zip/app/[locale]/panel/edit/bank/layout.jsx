export const metadata = {
  title: "ویرایش اطلاعات بانکی | پالم رنت",
  description: "ویرایش اطلاعات بانکی",
  icons: {
    icon: '/favicon.png',
  },
};

export default function PanelLayout({ children }) {
  return (
    <>
        { children }
    </>
  );
}
