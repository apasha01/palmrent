/* eslint-disable react-hooks/set-state-in-effect */
"use client";

import { useTranslations } from "next-intl";
import { IconDownload } from "@/components/Icons";

import {
  FinalDetail,
  PersonalInfoShow,
  ReservationDetail,
  SocialBox,
  VoucherHead,
} from "@/components/VoucherStep";
import { useParams, notFound } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import QRCode from "react-qr-code";
import { BASE_URL } from "../../../../lib/apiClient";
import { Download } from "lucide-react";

/** ✅ types */
type VoucherOption =
  | "noDeposite"
  | "freeDelivery"
  | "unlimitedKilometers"
  | "freeinsurance";

type VoucherItem = {
  branch: string;
  email: string;
  name: string;
  phone: string;
  code: string;
  created_date: string;
  rent_delivery: string;
  rent_from: string;
  rent_days: number | string;
  rent_return: string;
  rent_to: string;
  car_gearbox: string;
  car_fuel: string;
  car_baggage: number | string;
  car_person: number | string;
  car_name: string;
  car_year: number | string;
  photo: string;
  insurance_complete_price: number | string;
  car_km: "yes" | "no" | string;
  car_free_delivery: "yes" | "no" | string;
  car_deposit: "yes" | "no" | string;
  car_deposit_price: number | string;
  [key: string]: unknown;
};

type VoucherData = {
  item: VoucherItem;
  currency: string;
  toman?: boolean;
};

type ApiResponse =
  | { status: 404; data?: null }
  | { status: number; data: VoucherData };

export default function VoucherPage() {
  const [data, setData] = useState<VoucherData | null>(null);
  const [is404, setIs404] = useState(false);
  const [currentUrl, setCurrentUrl] = useState("");

  const params = useParams();
  const rawId = params?.id;

  // ✅ id می‌تونه string یا string[] باشه
  const id = useMemo(() => {
    if (Array.isArray(rawId)) return rawId[0] ?? "";
    return typeof rawId === "string" ? rawId : "";
  }, [rawId]);

  const t = useTranslations();

  async function fetchData(rentId: string) {
    try {
      const res = await fetch(`${BASE_URL}/car/rent/${rentId}/en/receipt`, {
        cache: "no-store",
      });


      const json = (await res.json()) as ApiResponse;

      // بعضی بک‌اندها status رو داخل json می‌دن:
      if ("status" in json && json.status === 404) {
        setIs404(true);
        return;
      }

      if ("data" in json && json.data) {
        setData(json.data);
      } else {
        // اگر ساختار غیرمنتظره بود
        setIs404(true);
      }
    } catch (err) {
      console.error(err);
      setIs404(true);
    }
  }

  useEffect(() => {
    if (!id) return;
    fetchData(id);

    // window فقط در client
    setCurrentUrl(window.location.href);
  }, [id]);

  // ✅ options typed
  const options = useMemo<VoucherOption[]>(() => {
    if (!data) {
      return ["noDeposite", "freeDelivery", "unlimitedKilometers", "freeinsurance"];
    }

    const opts: VoucherOption[] = [];

    const insurancePrice = Number(data.item.insurance_complete_price ?? 0);
    if (insurancePrice === 0) opts.push("freeinsurance");

    if (data.item.car_km !== "yes") opts.push("unlimitedKilometers");
    if (data.item.car_free_delivery === "yes") opts.push("freeDelivery");
    if (data.item.car_deposit !== "yes") opts.push("noDeposite");

    return opts;
  }, [data]);

  if (is404) {
    notFound();
  }

  return (
    <>
      {!data ? (
        <VoucherSkeleton />
      ) : (
        <div>
          <VoucherHead />
          <div className="lg:w-[85vw] sm:w-[90vw] w-[95vw] max-w-334 m-auto">
            <div className="flex sm:flex-row flex-col-reverse flex-wrap gap-4 my-4">
              <PersonalInfoShow
                branch={data.item.branch}
                email={data.item.email}
                name={data.item.name}
                phoneNumber={data.item.phone}
                resCode={data.item.code}
                resTime={data.item.created_date}
              />

              <div className="xl:w-1/3 md:w-3/12 w-full xl:text-base text-xs text-center bg-white rounded-2xl flex flex-col items-center justify-between py-4">
                <div className="text-[#DF900A]">{t("qrText")}</div>

                <QRCode
                  value={currentUrl}
                  size={200}
                  bgColor="#ffffff"
                  fgColor="#000000"
                  level="Q"
                />

                <button className="bg-[#3B82F61A] cursor-pointer rounded-lg flex items-center gap-4 py-2 px-4 text-[#3B82F6] mt-4">
                  <Download />
                  {t("downloadVoucher")}
                </button>
              </div>
            </div>

            <ReservationDetail
              deliveryPlace={data.item.rent_delivery}
              from={data.item.rent_from}
              resDays={data.item.rent_days}
              returnPlace={data.item.rent_return}
              to={data.item.rent_to}
              car_gearbox={data.item.car_gearbox}
              car_fuel={data.item.car_fuel}
              bag_count={data.item.car_baggage}
              person_count={data.item.car_person}
              car_name={data.item.car_name}
              car_year={data.item.car_year}
              // options={options}
              image={data.item.photo}
            />

            <div className="border border-[#0000001f] shadow-[0_2px_5px_-1px_rgba(0,0,0,.08)] p-4 rounded-4xl my-4 flex-1 bg-white">
              {/* <PaymentDetail
                data={data.item}
                currency={data.currency}
                borderLess={true}
                toman={data.toman}
              />

              {data.item.car_deposit === "yes" && (
                <FineDeposit
                  price={data.item.car_deposit_price}
                  currency={data.currency}
                  borderLess={true}
                />
              )} */}
            </div>

            <FinalDetail data={data.item} currency={data.currency} />
            <SocialBox />
          </div>
        </div>
      )}
    </>
  );
}

export function VoucherSkeleton() {
  return (
    <div>
      <div className="my-14 flex flex-col gap-2">
        <div className="animate-skeleton w-full h-20"></div>
        <div className="animate-skeleton w-full h-20"></div>
      </div>
      <div className="lg:w-[85vw] sm:w-[90vw] w-[95vw] max-w-334 m-auto">
        <div className="flex sm:flex-row flex-col-reverse flex-wrap gap-4 my-4 h-96">
          <div className="flex-1 h-full animate-skeleton rounded-lg"></div>
          <div className="xl:w-1/3 h-full animate-skeleton md:w-3/12 w-full xl:text-base text-xs text-center bg-white rounded-2xl flex flex-col items-center justify-between py-4"></div>
        </div>
        <div className="flex h-96 bg-white rounded-lg my-8 p-8 gap-8">
          <div className="w-5/12 animate-skeleton rounded-lg"></div>
          <div className="flex flex-col h-full gap-2 flex-1">
            <div className="animate-skeleton h-full rounded-lg"></div>
            <div className="animate-skeleton h-full rounded-lg"></div>
            <div className="animate-skeleton h-full rounded-lg"></div>
            <div className="animate-skeleton h-full rounded-lg"></div>
            <div className="animate-skeleton h-full rounded-lg"></div>
          </div>
        </div>
        <div className="p-4 rounded-4xl my-4 flex-1 animate-skeleton h-150"></div>
        <div className="p-4 rounded-4xl my-4 flex-1 animate-skeleton h-75"></div>
        <div className="p-4 rounded-4xl my-4 flex-1 flex gap-8 w-full">
          <div className="w-full h-20 animate-skeleton rounded-lg"></div>
          <div className="w-full h-20 animate-skeleton rounded-lg"></div>
          <div className="w-full h-20 animate-skeleton rounded-lg"></div>
          <div className="w-full h-20 animate-skeleton rounded-lg"></div>
          <div className="w-full h-20 animate-skeleton rounded-lg"></div>
        </div>
      </div>
    </div>
  );
}
