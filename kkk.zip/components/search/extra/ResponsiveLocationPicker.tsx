/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import * as React from "react";
import { cn } from "@/lib/utils";
import { Info, ArrowRight, MapPin } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Checkbox } from "@/components/ui/checkbox";

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";

import type { LocationState } from "@/types/rent-information";

// ---------------- Types ----------------
type PlaceRow = {
  id: number | string;
  title: string;
  price_pay?: string | number;
  pre_price_pay?: string | number;

  // ✅ from API
  need_address?: "yes" | "no";
  address_title?: string | null;
};

type Props = {
  open: boolean;
  onOpenChange: (open: boolean) => void;

  title: string;
  currencyLabel: string;

  places: PlaceRow[];

  value: LocationState;
  onChange: (next: LocationState) => void;
};

// ---------------- Helpers ----------------
function useIsMobile(breakpoint = 1024) {
  const [isMobile, setIsMobile] = React.useState(false);

  React.useEffect(() => {
    const mq = window.matchMedia(`(max-width: ${breakpoint - 1}px)`);
    const onChange = () => setIsMobile(mq.matches);
    onChange();
    mq.addEventListener?.("change", onChange);
    return () => mq.removeEventListener?.("change", onChange);
  }, [breakpoint]);

  return isMobile;
}

function toPriceNumber(x: any) {
  const n = typeof x === "number" ? x : parseFloat(String(x ?? "0"));
  return Number.isFinite(n) ? n : 0;
}

function oneLine(s: string) {
  return String(s || "").replace(/\s+/g, " ").trim();
}

// ---------------- Row ----------------
type RowProps = {
  id: string;
  title: string;
  priceNum: number;
  isFree: boolean;

  selectedKey: string;
  currencyLabel: string;
  onSelect: (id: string) => void;

  needAddress?: boolean;

  // ✅ فقط برای ردیف انتخاب‌شده
  selectedAddress?: string;
};

function LocationRow({
  id,
  title,
  priceNum,
  isFree,
  selectedKey,
  currencyLabel,
  onSelect,
  needAddress,
  selectedAddress,
}: RowProps) {
  const checked = selectedKey === id;
  const showAddr = checked && needAddress && oneLine(selectedAddress || "").length > 0;

  return (
    <div
      role="button"
      tabIndex={0}
      onClick={() => onSelect(id)}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") onSelect(id);
      }}
      className={cn(
        "rounded-2xl border bg-white transition-colors",
        checked ? "border-blue-200" : "border-gray-200",
        "hover:bg-gray-50 cursor-pointer select-none",
      )}
    >
      <div className="flex items-center justify-between gap-3 p-3">
        {/* RIGHT */}
        <div className="flex items-center gap-3 min-w-0">
          <Checkbox
            variant="info"
            checked={checked}
            onCheckedChange={() => onSelect(id)}
            onClick={(e) => e.stopPropagation()}
            className="h-5 w-5"
          />

          <div className="min-w-0">
            <div className="text-sm font-semibold text-gray-900 truncate">{title}</div>

            <div className="text-xs text-gray-500 mt-1 flex items-center gap-2">
              <span>هزینه: {isFree ? "رایگان" : `${priceNum.toLocaleString()} ${currencyLabel}`}</span>

              {needAddress ? (
                <span className="inline-flex items-center gap-1 text-[11px] text-amber-800 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-100">
                  نیاز به آدرس
                </span>
              ) : null}
            </div>
          </div>
        </div>

        {/* LEFT */}
        <Badge variant="secondary" className="rounded-full whitespace-nowrap">
          {isFree ? "رایگان" : `${priceNum.toLocaleString()}`}
        </Badge>
      </div>

      {/* ✅ ساده‌ترین نمایش آدرس: فقط یک خط زیر ردیف */}
      {showAddr ? (
        <div className="px-3 pb-3">
          <div className="flex items-start gap-2 rounded-xl bg-gray-50 px-3 py-2 border border-gray-100">
            <MapPin className="size-4 text-gray-400 mt-0.5" />
            <div className="min-w-0">
              <div className="text-[11px] text-gray-500">آدرس ثبت‌شده</div>
              <div className="text-xs text-gray-800 truncate">{oneLine(selectedAddress || "")}</div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

// ---------------- Main Component ----------------
export default function ResponsiveLocationPicker({
  open,
  onOpenChange,
  title,
  currencyLabel,
  places,
  value,
  onChange,
}: Props) {
  const isMobile = useIsMobile(1024);

  // ✅ انتخاب واقعی
  const selectedKey = value?.location != null ? String(value.location) : "";

  // ✅ state انتخابِ در انتظار (برای need_address=yes)
  const [addressOpen, setAddressOpen] = React.useState(false);
  const [pendingKey, setPendingKey] = React.useState<string>("");
  const [pendingTitle, setPendingTitle] = React.useState<string>("");
  const [pendingAddressLabel, setPendingAddressLabel] = React.useState<string>("آدرس");
  const [pendingAddress, setPendingAddress] = React.useState<string>("");

  const placesSafe = React.useMemo(() => (Array.isArray(places) ? places : []), [places]);

  const getPlaceById = React.useCallback(
    (id: string) => placesSafe.find((p) => String((p as any)?.id) === String(id)),
    [placesSafe],
  );

  // ✅ وقتی کل picker بسته شد، اگر آدرس باز بوده جمعش کن
  React.useEffect(() => {
    if (!open) {
      setAddressOpen(false);
      setPendingKey("");
      setPendingTitle("");
      setPendingAddress("");
    }
  }, [open]);

  // ✅ انتخاب یک گزینه
  const selectKey = React.useCallback(
    (key: string) => {
      const p = getPlaceById(key);
      if (!p) return;

      const needAddress = String((p as any)?.need_address || "no") === "yes";

      if (!needAddress) {
        onChange({
          ...value,
          isDesired: false,
          location: String(key),
          address: "",
        });
        onOpenChange(false);
        return;
      }

      // ✅ اگر نیاز به آدرس دارد: صفحه آدرس باز شود
      setPendingKey(String(key));
      setPendingTitle(String((p as any)?.title ?? ""));
      setPendingAddressLabel(String((p as any)?.address_title || "آدرس"));

      // اگر قبلاً همین گزینه انتخاب شده بود، آدرس قبلی را برای ویرایش پر کن
      const isSame = value?.location != null && String(value.location) === String(key);
      setPendingAddress(isSame ? String(value.address || "") : "");

      setAddressOpen(true);
    },
    [getPlaceById, onChange, onOpenChange, value],
  );

  // ✅ Cancel آدرس: فقط برگرد به لیست
  const cancelAddress = React.useCallback(() => {
    setAddressOpen(false);
    setPendingKey("");
    setPendingTitle("");
    setPendingAddress("");
  }, []);

  // ✅ Confirm آدرس: اینجا انتخاب ثبت شود + کل picker بسته شود
  const confirmAddress = React.useCallback(() => {
    const addr = oneLine(pendingAddress);
    if (!addr) return;

    onChange({
      ...value,
      isDesired: true,
      location: String(pendingKey),
      address: addr,
    });

    setAddressOpen(false);
    setPendingKey("");
    setPendingTitle("");
    setPendingAddress("");

    onOpenChange(false);
  }, [onChange, onOpenChange, pendingAddress, pendingKey, value]);

  // ✅ Header لیست (بک => بستن picker)
  const ListHeader = (
    <div className="shrink-0 px-4 py-2 border-b bg-gray-50">
      <div className="flex items-center">
        <button
          type="button"
          onClick={() => onOpenChange(false)}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full hover:bg-gray-100"
          aria-label="بازگشت"
        >
          <ArrowRight size={20} className="text-gray-700" />
        </button>

        <div className="mr-2 font-bold text-gray-900 text-right">{title}</div>
      </div>
    </div>
  );

  // ✅ Header آدرس (بک => برگشت به لیست)
  const AddressHeader = (
    <div className="shrink-0 px-4 py-2 border-b bg-gray-50">
      <div className="flex items-center">
        <button
          type="button"
          onClick={cancelAddress}
          className="inline-flex h-9 w-9 items-center justify-center rounded-full hover:bg-gray-100"
          aria-label="بازگشت"
        >
          <ArrowRight size={20} className="text-gray-700" />
        </button>

        <div className="mr-2 font-bold text-gray-900 text-right">{pendingTitle || "آدرس"}</div>
      </div>
    </div>
  );

  // ✅ List Content
  const ListContent = (
    <div className="space-y-3">
      {placesSafe.map((item, index) => {
        const id = String((item as any)?.id ?? index);
        const priceNum = toPriceNumber((item as any)?.price_pay);
        const isFree = priceNum <= 0;
        const needAddress = String((item as any)?.need_address || "no") === "yes";

        // ✅ فقط اگر همین ردیف انتخاب شده باشد، آدرس نشان بده
        const selectedAddress =
          selectedKey === id ? String((value as any)?.address || "") : "";

        return (
          <LocationRow
            key={id}
            id={id}
            title={String((item as any)?.title ?? "")}
            priceNum={priceNum}
            isFree={isFree}
            selectedKey={selectedKey}
            currencyLabel={currencyLabel}
            onSelect={selectKey}
            needAddress={needAddress}
            selectedAddress={selectedAddress}
          />
        );
      })}
    </div>
  );

  const Footer = (
    <div className="shrink-0 border-t bg-white px-4 py-4 space-y-3">
      <div className="text-[11px] text-gray-500 flex items-start gap-2">
        <Info size={14} className="mt-0.5 text-gray-400" />
        <span>بعد از انتخاب، روی «انجام شد» بزنید.</span>
      </div>

      <Button type="button" className="w-full h-12 rounded-xl font-extrabold" onClick={() => onOpenChange(false)}>
        انجام شد
      </Button>
    </div>
  );

  const MobilePage = (
    <div className="relative h-dvh w-full flex flex-col overflow-hidden">
      {ListHeader}
      <div className="flex-1 overflow-hidden">
        <ScrollArea className="h-full">
          <div className={cn("p-4", "pb-28")}>{ListContent}</div>
        </ScrollArea>
      </div>
      {Footer}
    </div>
  );

  // ================= Address UI =================
  const AddressContent = (
    <div className="space-y-4 p-4">
      <div className="space-y-1">
        <Label className="text-xs text-gray-600 text-right">{pendingAddressLabel}</Label>
        <Input
          value={pendingAddress}
          onChange={(e) => setPendingAddress(e.target.value)}
          placeholder={pendingAddressLabel}
          className="h-11 rounded-lg border-gray-300"
        />
        <div className="text-[11px] text-gray-500 text-right">برای ثبت انتخاب، وارد کردن آدرس الزامی است.</div>
      </div>

      <div className="flex gap-2">
        <Button type="button" variant="outline" className="flex-1 h-11 rounded-xl" onClick={cancelAddress}>
          انصراف
        </Button>

        <Button
          type="button"
          className="flex-1 h-11 rounded-xl font-extrabold"
          disabled={oneLine(pendingAddress).length === 0}
          onClick={confirmAddress}
        >
          ثبت
        </Button>
      </div>
    </div>
  );

  // ✅ Mobile
  if (isMobile) {
    return (
      <>
        <Sheet open={open} onOpenChange={onOpenChange}>
          <SheetContent
            showCloseButton={false}
            side="right"
            className={cn("p-0", "h-dvh w-screen max-w-none", "rounded-none border-0", "overflow-hidden")}
          >
            <SheetHeader className="sr-only">
              <SheetTitle>{title}</SheetTitle>
            </SheetHeader>

            {MobilePage}
          </SheetContent>
        </Sheet>

        {/* Address Sheet */}
        <Sheet
          open={addressOpen}
          onOpenChange={(v) => {
            if (v) setAddressOpen(true);
            else cancelAddress();
          }}
        >
          <SheetContent
            showCloseButton={false}
            side="right"
            className={cn("p-0", "h-dvh w-screen max-w-none", "rounded-none border-0", "overflow-hidden")}
          >
            <div className="h-dvh flex flex-col">
              {AddressHeader}
              <div className="flex-1 overflow-auto">{AddressContent}</div>
            </div>
          </SheetContent>
        </Sheet>
      </>
    );
  }

  // ✅ Desktop
  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent showCloseButton={false} className="max-w-130 p-0 overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>{title}</DialogTitle>
          </DialogHeader>

          <div className="h-[70vh] flex flex-col">
            {ListHeader}

            <div className="flex-1 overflow-hidden">
              <ScrollArea className="h-full">
                <div className={cn("p-4", "pb-28")}>{ListContent}</div>
              </ScrollArea>
            </div>

            {Footer}
          </div>
        </DialogContent>
      </Dialog>

      {/* Address Dialog */}
      <Dialog
        open={addressOpen}
        onOpenChange={(v) => {
          if (v) setAddressOpen(true);
          else cancelAddress();
        }}
      >
        <DialogContent className="max-w-md p-0 overflow-hidden">
          <DialogHeader className="sr-only">
            <DialogTitle>ثبت آدرس</DialogTitle>
          </DialogHeader>

          <div className="flex flex-col">
            {AddressHeader}
            {AddressContent}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
