/* eslint-disable @typescript-eslint/no-explicit-any */
"use client";

import * as React from "react";
import { Info, Tag, CalendarDays } from "lucide-react";

import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import {
  Drawer,
  DrawerClose,
  DrawerContent,
  DrawerFooter,
  DrawerHeader,
  DrawerTitle,
  DrawerTrigger,
} from "@/components/ui/drawer";
import {
  Dialog,
  DialogClose,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";

type PriceRow = {
  range?: string;
  base_price?: number | string;
  final_price?: number | string;
};

function safeNum(v: any, fallback = 0): number {
  const n = typeof v === "number" ? v : parseFloat(String(v ?? ""));
  return Number.isFinite(n) ? n : fallback;
}

function formatNum(n: number) {
  return new Intl.NumberFormat("fa-IR").format(Math.round(n));
}

type PriceGroupsResponsiveProps = {
  trigger: React.ReactNode;
  prices?: PriceRow[] | null;
  currencyLabel?: string;
  title?: string;
  closeLabel?: string;
  subtitle?: string;
};

function PriceListBody({
  prices,
  currencyLabel,
  subtitle,
}: {
  prices: PriceRow[];
  currencyLabel: string;
  subtitle?: string;
}) {
  const rows = Array.isArray(prices) ? prices.filter(Boolean) : [];

  const finals = rows
    .map((r) => safeNum(r.final_price, 0))
    .filter((n) => Number.isFinite(n) && n > 0);

  return (
    <div className="px-4 pb-2 text-right">
      <div className="flex items-start justify-between gap-3">
        <div className="">
          <div className="text-xs text-gray-500 leading-5">
            {subtitle ?? "قیمت‌ها به ازای هر روز محاسبه شده‌اند."}
          </div>
        </div>

      </div>

      <Separator className="my-3" />

      {rows.length === 0 ? (
        <div className="text-sm text-gray-500 text-right py-6">
          گروه قیمتی برای این خودرو موجود نیست.
        </div>
      ) : (
        <div className="space-y-2">
          {rows.map((r, idx) => {
            const range = String(r.range ?? "").trim();
            const base = safeNum(r.base_price, 0);
            const final = safeNum(r.final_price, 0);
            const hasDiscount = base > 0 && final > 0 && base !== final;

            return (
              <div
                key={idx}
                className="rounded-2xl border border-gray-200 bg-white p-3 shadow-sm"
              >
                <div className="flex items-start justify-between gap-3">
                  {/* Left price block */}


                  {/* Right range block */}
                  <div className="text-right">
                    <div className="flex items-center justify-start gap-2">
                      <CalendarDays className="size-4 text-gray-400" />
                      <div className="text-sm font-extrabold text-gray-900">
                        {range || `بازه ${idx + 1}`}
                      </div>
                    </div>

                    <div className="mt-1 text-xs text-gray-500">
                      {hasDiscount ? "قیمت پایه و قیمت بعد از تخفیف" : "قیمت روزانه"}
                    </div>
                  </div>

                                    <div className="text-left whitespace-nowrap">
                    <div className="text-sm font-extrabold text-gray-900">
                      {final > 0 ? formatNum(final) : "—"}{" "}
                      <span className="text-xs font-normal text-gray-500">{currencyLabel}</span>
                    </div>

                    {hasDiscount ? (
                      <div className="mt-1 inline-flex items-center gap-2 justify-end">
                        <span className="text-xs text-gray-400 line-through">
                          {formatNum(base)} {currencyLabel}
                        </span>
                   
                      </div>
                    ) : null}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

/**
 * ✅ Mobile: Drawer
 * ✅ md+: Dialog
 * ✅ RTL Fix: dir="rtl" روی Content ها
 */
export function PriceGroupsResponsive({
  trigger,
  prices,
  currencyLabel = "",
  title = "گروه‌های قیمتی",
  closeLabel = "بستن",
  subtitle,
}: PriceGroupsResponsiveProps) {
  const rows = Array.isArray(prices) ? prices.filter(Boolean) : [];

  return (
    <>
      {/* ================= Mobile (Drawer) ================= */}
      <div className="md:hidden">
        <Drawer>
          <DrawerTrigger asChild>{trigger}</DrawerTrigger>

          <DrawerContent dir="rtl" className="max-h-[85vh]">
            <DrawerHeader className="text-right px-4">
              <DrawerTitle className="flex items-center gap-1 text-base">
                <Info className="size-4 text-gray-500" />
                {title}
              </DrawerTitle>
            </DrawerHeader>

            <PriceListBody prices={rows} currencyLabel={currencyLabel} subtitle={subtitle} />

            <DrawerFooter className="px-4">
              <DrawerClose asChild>
                <Button variant="outline" className="h-12 rounded-2xl w-full">
                  {closeLabel}
                </Button>
              </DrawerClose>
            </DrawerFooter>
          </DrawerContent>
        </Drawer>
      </div>

      {/* ================= Desktop (Dialog) ================= */}
      <div className="hidden md:block">
        <Dialog>
          <DialogTrigger asChild>{trigger}</DialogTrigger>

          <DialogContent dir="rtl" className="max-w-2xl p-0 overflow-hidden">
            <div className="p-4">
              <DialogHeader>
                <DialogTitle className="text-right flex items-center justify-end gap-2">
                  <Info className="size-4 text-gray-500" />
                  {title}
                </DialogTitle>
              </DialogHeader>
            </div>

            <div className="px-2 pb-2">
              <PriceListBody prices={rows} currencyLabel={currencyLabel} subtitle={subtitle} />
            </div>

            <div className="p-4 pt-2">
              <Separator className="mb-3" />
              <div className="flex justify-end">
                <DialogClose asChild>
                  <Button variant="outline" className="h-11 rounded-2xl">
                    {closeLabel}
                  </Button>
                </DialogClose>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </>
  );
}
