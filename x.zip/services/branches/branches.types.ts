export type Branch = {
  id: number;
  slug: string;
  title: string;
};
