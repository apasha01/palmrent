/* eslint-disable @typescript-eslint/no-explicit-any */
// branch-cars.types.ts

export type Car = any;

export type BranchCarsResponse = any;

// اگه کل response (با meta/status) رو هم می‌خوای:
export type BranchCarsApiResponse = any;
